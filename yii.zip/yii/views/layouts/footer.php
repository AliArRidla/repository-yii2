 <footer class="main-footer">
     <div class="footer-left">
         Copyright &copy; 2021 <div class="bullet"></div> Modified for <a href="https://polinema.ac.id">Test Soal Magang</a>
     </div>
     <div class="footer-right">
         1.0.0
     </div>
 </footer>